small 4 channel mixer for modular synths.  Just download the repository and have the gerber files printed by your favourite PCB manufacturing company.

<img width="1708" height="962" alt="4 Channel Mixer - Image" src="https://github.com/user-attachments/assets/293eb42f-172c-4be5-a5b0-aadf09cd2cba" />

